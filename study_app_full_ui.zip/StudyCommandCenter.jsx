import { useState } from 'react';
import Dashboard from './ui/Dashboard.jsx';
import StudyTimer from './ui/StudyTimer.jsx';
import Uploads from './ui/Uploads.jsx';
import Flashcards from './ui/Flashcards.jsx';
import NotesCanvas from './ui/NotesCanvas.jsx';
import Analytics from './ui/Analytics.jsx';
import HomerAI from './ui/HomerAI.jsx';
import Settings from './ui/Settings.jsx';

export default function StudyCommandCenter() {
  const [page, setPage] = useState("dashboard");

  const screens = {
    dashboard: <Dashboard />,
    timer: <StudyTimer />,
    upload: <Uploads />,
    flashcards: <Flashcards />,
    notes: <NotesCanvas />,
    analytics: <Analytics />,
    homer: <HomerAI />,
    settings: <Settings />
  };

  return (
    <div className="app-shell">
      <nav className="sidebar">
        {Object.keys(screens).map(key => (
          <button key={key} onClick={() => setPage(key)}>
            {key.toUpperCase()}
          </button>
        ))}
      </nav>
      <main className="screen-area">
        {screens[page]}
      </main>
    </div>
  );
}